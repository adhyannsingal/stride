# Outlook acceptance results

**Initial status:** new implementation tests NOT RUN. The handoff is a specification; do not inherit a PASS from the reference kit.

- Actual team start time / timezone:
- Build freeze time:
- Submission deadline:
- Current repository commit:
- Deployed URL:
- Phone/iOS and AirPods actually tested:
- Camera source / verified board revision:
- Feedback source / verified motor voltage:
- Persistence configuration / restart limitation:
- Owner of submission:

| Test ID | PASS / FAIL / BLOCKED / NOT RUN | Real / simulated / fixture | Evidence and measurement | Owner |
| --- | --- | --- | --- | --- |
| A01 | NOT RUN | — | | 1 |
| A02 | NOT RUN | — | Phone works with local Mac server stopped | 2/3 |
| A03 | NOT RUN | — | | 3 |
| A04 | NOT RUN | — | Live model request and latency | 1/3 |
| A05 | NOT RUN | — | | 1 |
| A06 | NOT RUN | — | | 1/3 |
| A07 | NOT RUN | — | Include durability/restart check | 1/3 |
| A08 | NOT RUN | — | Human confirms audible AirPods playback | 3 |
| A09 | NOT RUN | — | | 2 |
| A10 | NOT RUN | — | | 2 |
| A11 | NOT RUN | — | Physical rail/pattern/output evidence | 2 |
| A12 | NOT RUN | — | Physical local alert without internet | 2/3 |
| A13 | NOT RUN | — | Runs/searches/approaches; record misses | all |
| A14 | NOT RUN | — | Power/reset/heat and local latency | 1/2 |
| A15 | NOT RUN | — | | 3 |
| A16 | NOT RUN | — | | 1/2 |

## Measurements

- Capture → backend receipt:
- Model request → validated result:
- Capture → spoken result age:
- Route action → command accepted:
- Physical local obstacle → buzzer/motor start:
- Board resets / run duration:
- Searches attempted / correct / not found / failed:
- Unknown/no-echo behavior:

## Honest demo feature status

| Feature | Implemented? | Actually tested source/device | Limitation shown to judges |
| --- | --- | --- | --- |
| Phone guided route | Pending | | |
| AirPods speech | Pending | | |
| Gemini objects/find | Pending | | |
| Route/sighting memory | Pending | | |
| W11 source | Pending | | |
| Physical ultrasonic alerts | Pending | | |
| Physical 3 V motor patterns | Pending | | |
| Laptop-free hosted runtime | Pending | | |

## Final blockers and chosen fallbacks

Record each blocker, owner, deadline cutoff, chosen labeled fallback and affected claims here. Do not erase failures to make the table look complete.

## Mandatory live vision gates

| ID | Status | Evidence |
| --- | --- | --- |
| L01 | NOT RUN | 60 s automatic detection, result rate and p50/p95/max age |
| L02 | NOT RUN | Slow network/inference, bounded queue and stale suppression |
| L03 | NOT RUN | Source switch, pause/resume and old-track invalidation |
| L04 | NOT RUN | Stable speech, cooldown and sensor priority |
| L05 | NOT RUN | Actual W11 glasses → hosted detector → iPhone/AirPods |
| L06 | NOT RUN | Supported objects and recorded missed hazards |
