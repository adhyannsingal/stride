# Outlook recording and submission

## Before recording

- [ ] Build frozen; exact working Git commit recorded.
- [ ] Phone HTTPS app works; public deployment warm and reachable.
- [ ] Gemini key/quota/model tested; no secrets visible in screen recording.
- [ ] Actual camera/feedback source labels match the demonstrated setup.
- [ ] AirPods voice audibly confirmed; local buzzer/motor checked if claimed.
- [ ] Checked route and sighted spotter ready; no blindfolded walking or traffic demo.
- [ ] Any hardware/phone-camera/simulator fallback explained in the script.
- [ ] Organizer duration, required tools/evidence and submission fields checked by a human.

## Example 2–3 minute script

1. **Purpose:** “Outlook explores navigation assistance for blind and low vision users through route guidance, proximity alerts, speech and vibration.”
2. **Navigation:** select a checked route on the phone; show the current instruction, Repeat and explicit confirmation. Explain that progress is confirmed, not autonomously localized.
3. **Feedback:** present a controlled obstacle to the real sensor and show alert priority if validated. Otherwise show the simulator with its label and state that physical integration is pending.
4. **Memory:** recall confirmed route progress and a sighting with age.
5. **Live awareness:** after a single Start, introduce/move supported objects and show automatic current detections and stabilized speech. Display result age/rate. A manual object search can be additional, not the proof of live vision. No prerecorded result labeled live.
6. **Architecture:** phone + hosted service + glasses/controller; demonstrate the Mac development server is unnecessary if the deployed path passed.
7. **Limits:** current sensor coverage and prototype state; no claim of universally safe navigation or room-anchored sound.

Approximate final-hour allocation: record 20 minutes, edit 20, upload/forms 15, verify links 5. Submit before the actual deadline even if an optional feature is unfinished.

## Submission

- [ ] Project title consistently Outlook; repository name may remain stride.
- [ ] README describes actual feature status and tested commands.
- [ ] Repository URL and visibility/access verified.
- [ ] Deployment URL reachable in a fresh phone browser.
- [ ] Video plays signed out with intended permissions; audio audible.
- [ ] Hardware diagram/photo and source/tool attribution included where requested.
- [ ] QA results and limitations match the video narration.
- [ ] Required organizer/Kiro evidence attached if applicable.
- [ ] All team names/required fields filled by the humans; no invented details.
- [ ] Final submission receipt/URLs saved and one teammate verifies them independently.
