# Outlook build spec — six-hour team handoff

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

**Product:** navigation assistance glasses for blind and low vision users. Navigation guidance, immediate proximity alerts, AirPods speech and directional vibration are the core. Object awareness, object finding and last-seen memory support those tasks.

**Repository:** `https://github.com/adhyannsingal/stride` · **Team:** three people with one coding agent per workstream · **Budget:** six hours to build, then one hour for video and submission.

**Authority:** this document and `contracts/API.md` replace the old 36–48-hour plan. Keep the GitHub repository name `stride`; use **Outlook** in new product text, following the selected name. The existing README mixes STRIDE and Outlook. Do not rename the repository as part of this sprint.

## 1. Starting point and nonnegotiable decisions

Reviewed `main` at commit `8d19944af6acc6e10352fb01cec846f7c84dd196`: its root contains `README.md` and `buildspec_outlook.md`; no application, dependency manifest, tests or firmware were present in that snapshot. Recheck HEAD before coding because teammates may have added work. Preserve any new implementation.

The old documents have four material problems: a 36–48-hour schedule, a laptop in the wearable runtime, a leftover 5 V motor entry despite the confirmed 3 V motor, and links to companion documents absent from the repository. Correct all four.

Locked architecture for this deadline:

1. **Phone web app over HTTPS**, using iPhone 14 Safari, with Mac webcam development support. Vanilla HTML/CSS/JavaScript; no native iOS build or frontend framework migration.
2. **Hosted FastAPI backend** for Gemini, sessions, route state, memory and device messages. The Mac is a development station; it is not carried during the final wearable demonstration.
3. **Continuous hosted YOLO perception is P0.** Frames are processed automatically without repeated Analyze clicks; the wearer carries no Mac. OpenCV/preprocessing is supporting code; Gemini is optional requested enrichment, outside the immediate warning loop.
4. **Independent DevKit alert loop:** HC-SR04 → local buzzer/motor. Cloud outages must not stop local sensing.
5. **One confirmed 3 V motor:** learned pulse patterns for directions. A second motor is optional; never describe one motor as physical left/right feedback.
6. **Checked-route navigation with explicit checkpoint confirmation** is the shippable baseline. User-facing name: “Guided route.” GPS destination routing is optional after the baseline passes; no autonomous localization claim.
7. **Software first:** mock device adapters and real webcam/phone images throughout hours 0–4.5. Prepare firmware/configuration in parallel. Humans assemble and validate hardware in hours 4.5–5.5, not during the submission hour.
8. **Person 3 stays exclusively software.** Persons 1 and 2 handle physical assembly when needed.

This handoff contains current specifications and agent assignments only. Agents implement the live application against the shared contracts; obsolete snapshot-only prototype files are not included.

## 2. Deliverable and feature cutoff

| ID | Required by hour 4.5 | Exact behavior and test |
| --- | --- | --- |
| F1 | Accessible phone app | iPhone opens public HTTPS URL; Start session enables audio; large labeled controls and VoiceOver labels. |
| F2 | Guided route | Select a saved route; start, confirm, repeat, pause/resume, stop; announce exactly the active instruction. Repeat never advances. |
| F3 | Route Memory | Save route steps, checked return instructions, confirmed events and session progress; reload preserves data within the configured persistence limits. |
| F4 | Continuous objects ahead | Automatically ingest and detect current webcam/phone/W11 frames; show measured result age/rate, stabilize announcements, and fail visibly on stale vision. See LIVE_VISION.md. |
| F5 | Find and recall | Find a named object; explicit not-found state; remember label/time/checkpoint/source; recall always states age. |
| F6 | Feedback arbiter | Obstacle/stop > fault > route > observation; cancel stale speech and direction commands. |
| F7 | Haptic protocol | One-motor left/right/straight/stop patterns; simulator first, device ACK and physical output at integration. |
| F8 | Device health | Real/simulated/unavailable labels; telemetry age, camera source, AI status and physical feedback ACK. |
| F9 | Hardware adapters | Authenticated W11 ingest and DevKit telemetry/commands/ACK; firmware ready before assembly. Actual output passes only after physical parts/configuration are available. |
| F10 | Deploy and evidence | Hosted health check, phone smoke test, acceptance report, runnable README and submission assets. |

**Live perception is P0, not stretch.** Implement the continuous detector/capture/feedback loop in LIVE_VISION.md before optional Gemini, GPS import or dashboard polish. A snapshot-only demonstration does not satisfy F4.

**P1 after the hour-3 integrated baseline:** GPS walking-route import, hold-to-talk, second motor, richer dashboard. Spend at most 30 minutes on one P1. **Cut for this deadline:** native ARKit, LiDAR, world-anchored sound, head tracking, custom model training, TimescaleDB, autonomous rerouting, hand-distance estimation and independent street-crossing guidance.

## 3. Wearable runtime and network

```text
W11 on glasses ── HTTPS JPEG upload ──┐
                                     ▼
iPhone browser ◄── HTTPS ── Hosted FastAPI ── hosted YOLO + optional Gemini API
  │   │                          │               (YOLO continuous; Gemini requested)
  │   └─ camera fallback         ├─ routes / memory / events
  │                              └─ device commands / ACKs
  └─ speech → AirPods Pro 3                    ▲
                                              │ HTTPS poll + telemetry
HC-SR04 → DevKit → local buzzer + 3 V motor ────┘
          independent local warning loop
```

Use a tested 2.4 GHz internet-capable hotspot/router for both boards. iPhone uses the same hotspot or cellular connectivity to the public backend. No browser request to a private ESP32 HTTP address is necessary; this avoids mixed-content/local-network-camera problems. A separate hotspot is the preferred filming network; an iPhone hotspot is allowed only after testing its exact board connectivity.

Live frames must carry capture times and automatic health reporting. Camera source is a session choice: `browser_camera`, `w11_camera` or `fixture`. Only one source is active for perception. Switches invalidate in-flight observations. W11 uploads do not silently replace a selected phone source.

The standard iPhone 14 has no rear LiDAR. AirPods speech is required; head tracking is not. Browser microphone input and browser vibration APIs are not required. Keep the phone app foreground/unlocked during the demo; background/lock-screen operation is not implemented.

## 4. Stack and repository layout

Use Python 3.11, FastAPI, Uvicorn, Pydantic v2, ONNX Runtime/NumPy for the exported live detector, SQLAlchemy and SQLite. Add `httpx` or the current Google GenAI SDK only for optional Gemini enrichment. Pick one Gemini client and lock resolved versions. Include Pillow if used to verify/decode images; avoid adding OpenCV for that purpose. Tests: pytest + HTTPX/TestClient; browser checks with Playwright if already available. Frontend is served by the same FastAPI origin, so there is one HTTPS deployment.

Required target layout, to be created by the assigned agents:

```text
README.md                         teammate-facing overview and actual run instructions
buildspec_outlook.md              this execution contract
AGENTS.md                        shared agent instructions
.env.example                     names only; no secrets
.gitignore                       ignores .env, secrets headers, images, DB and build outputs
requirements.txt                 pinned application and test requirements
render.yaml                      deployment template, no credentials
app/
  main.py                        app assembly, static serving, health
  settings.py  schemas.py        canonical settings and API models
  db.py  dependencies.py         engine, sessions, auth dependencies, initialization
  api/                           sessions, routes, frames, perception, memory
  services/                      Gemini, freshness, route logic, event persistence
  devices/                       telemetry policy, command queue, simulator, routers
web/
  index.html  styles.css  app.js
  api.js  camera.js  feedback.js  routes.js
firmware/
  camera/                        W11 sketch, board_config.example.h, secrets.example.h
  feedback/                      DevKit sketch and secrets.example.h
scripts/                         seed_demo.py, simulate_feedback.py, check_deploy.py
contracts/API.md  contracts/examples.json
tests/                           backend and firmware-policy contract tests
qa/RESULTS.md                    measured results and source/limitations
submission/                      team-filled pitch, script, URLs and checklist
```

Do not create a second React/Next.js app, monorepo toolchain, Redis, Docker orchestration or user-account system. One backend process/worker and one active demonstration session are sufficient.

## 5. Inputs and outputs

### Camera

- Capture unmirrored 640 × 480 JPEG initially; preserve aspect ratio and identify source/orientation.
- Browser uses `getUserMedia({video: {facingMode: {ideal: 'environment'}}, audio: false})`; Mac selects its available webcam. Allow camera switching if selection is wrong.
- W11 posts raw JPEG bytes, not multipart/base64, with metadata headers defined in the API contract. Target 5 fresh frames/s initially, gated by measured transport/inference performance, cap JPEG at 1 MB, retain latest frame only. Never queue a video history for Gemini.
- Validate actual image decoding, dimensions, content type and upload limits. Reject corrupt/oversized images. Frames remain in memory with a bounded lifetime; raw-image persistence is off.
- Every upload has device ID, boot ID, sequence, frame ID, session ID, capture timestamp and source. Boot IDs prevent sequence collisions after reboot.
- Device time sync uses server time/RTT or NTP; mark `clock_synced=false` until verified. Receipt time alone is not capture time. Never present uncertain or stale capture age as live.

### Optional Gemini snapshot perception

The continuous detector has its own stricter age/throughput policy in LIVE_VISION.md. The section below describes only requested Gemini enrichment.

If optional Gemini enrichment is implemented after the live loop passes, use one configurable image-capable model available to the team and verify it with a real request. Do not silently choose a different paid model or invent an ID.

Two tasks: `describe` and `find(target)`. Use structured output with this semantic schema:

```json
{
  "objects": [
    {"label": "chair", "box_2d": [100, 350, 850, 700]}
  ]
}
```

`box_2d` is `[ymin, xmin, ymax, xmax]`, each 0–1000. Validate finite numeric values, bounds, ordered corners, nonempty short labels and at most eight objects. `find` returns an empty list when absent. Do not solicit or display invented confidence scores. Ignore instructions embedded in scene text.

Calculate image-relative left/center/right from box center: less than 333, 333–667, greater than 667. Normalize frontend overlays consistently. Speak at most one useful observation per request; keep the full validated list on the dashboard. Object presence is not distance, navigability or an evasive turn.

One in-flight request per session, bounded global concurrency of two, 12 s provider timeout, no blind automatic retry. Honor 429/quota errors; show unavailable. Reserve no more than 60 successful perception calls per demonstration session initially; expose the count. Obtain image-upload consent in the UI. Keys are server-side only.

Check age before starting and again before speaking: live result maximum age **5 s**. Expired results receive `status=expired`, no live speech or turn command; keep latency/error metadata for QA. Do not relax freshness silently to make a demo look successful. Optional historical snapshot viewing must say “earlier image,” with age, and is not route guidance.

Deduplicate repeated observation speech: `(label, position)` cooldown of 5 s; Repeat can explicitly repeat the last observation with its age. Route and obstacle events always preempt this cooldown.

### Range and local alerts

DevKit samples at 100 ms intervals, 10 µs TRIG, 30 ms ECHO timeout; median of three valid readings. Distances outside a verified sensor range, missing pulses or invalid numerics become unknown. Starting warning bands: 60–100 cm slow, 30–60 cm faster, below 30 cm urgent; 5 cm hysteresis. Above 100 cm means outside the demo warning band, not safe.

On fresh warning telemetry, backend suppresses route/observation output; local DevKit buzzer/motor does not wait for that suppression round trip. Backend should not send a second stop vibration that duplicates the already-active local alert. Physical alert latency target: <500 ms, measured with the actual hardware.

Upload telemetry at 5 Hz initially, reducing upload rate if measured radio/TLS load interferes with local sensing; local sampling stays independent. Implement network work in a separate task or otherwise bounded/nonblocking design. UI telemetry older than 1 s is stale; loss is unknown, never a valid distance.

### One-motor feedback vocabulary

| Pattern | Motor waveform | Meaning |
| --- | --- | --- |
| `left` | 200 ms ON | Checked-route left cue |
| `right` | 200 ON / 200 OFF / 200 ON | Checked-route right cue |
| `straight` | 120 ON / 120 OFF / 120 ON / 120 OFF / 120 ON | Checked-route straight cue |
| `stop` | 800 ms ON plus local buzzer when obstacle-triggered | Stop/obstacle |
| `cancel` | OFF immediately | Cancel remote cue; must not disable local obstacle alert |

Pattern ID, not arbitrary GPIO or arbitrary motor duty, crosses the API. Driver defaults OFF at boot. Pattern timings use a nonblocking state machine. Priority local obstacle > local sensor fault > remote route > test. New obstacles cancel old turns; never replay them when the obstacle disappears. Link loss cancels remote cues and pending commands; local warnings stay enabled. Two-motor mapping may be added only after one channel passes.

## 6. Guided-route behavior

A route has name, ordered checkpoint IDs, text, direction pattern, optional location and separately checked return instructions. Include a route editor/import and one clearly labeled sample route. Physical route directions are supplied/checked by Persons 1/2; never ask the model to invent a walking route through a camera image.

State machine: `idle → guiding ↔ paused → completed`; obstacle introduces `blocked`; sensor fault introduces `sensor_unknown` as an overlay. Confirmation advances exactly one step; duplicate action IDs cannot skip steps. Repeat is side-effect-free for progress. Stop cancels pending remote commands and noncritical speech. Resume after a warning requires an explicit user action and a fresh nonwarning sensor state; stale automatic resume is prohibited.

`navigation_training` mode can use visibly simulated telemetry for development. `hardware_navigation` requires feedback-device health; without it, route instruction previews remain available but the UI says “sensor unavailable.” Do not substitute a mock reading to unlock the real-hardware mode.

Route Memory stores events, not estimated unseen movement. Checkpoint association for a sighting is the last user-confirmed checkpoint, labeled as such. Recall: “Mug last seen near confirmed checkpoint B, 42 seconds ago.” Do not claim that an object stayed there or give an automatically reversed route.

### Optional GPS route import

Only after the integrated P0 flow passes and an existing Mapbox token is available, Person 3 may spend 30 minutes calling the backend walking-route adapter (`mapbox/walking`, `steps=true`, GeoJSON). Choose from a few team-defined destinations with coordinates; address search/geocoding is outside this optional slice. Display provider steps and estimated distances with provider attribution.

Phone geolocation requires permission/HTTPS; show fix age and accuracy. Do not add automatic turn completion/rerouting within this sprint: retain explicit confirmation and label the imported route accordingly. If the provider/key/fix fails, return to the saved checked route with an explicit mode change. A map-provider route is not verified accessible or obstacle-free. The baseline must not depend on a new account.

## 7. Audio and phone interface

Start session is a user gesture that enables/test-plays speech. Use `speechSynthesis` with bounded utterances, cancellation and an `onerror` path. Test on actual iPhone Safari/AirPods by minute 60, not just desktop. AirPods output is selected by the operating system; the app must not claim it can force that output.

Home screen: session state; Begin guided route; Confirm checkpoint; Repeat; Pause/Resume; Stop; Describe ahead; Find object; Recall; Settings. Show camera/feedback/AI connection status and source badges. Stop is always reachable. Controls use accessible names, visible keyboard focus, minimum 44 px touch targets and meaningful live-region announcements. Do not announce an entire debugging log through VoiceOver.

Feedback priority: local obstacle/stop > sensor/network fault > route instruction > object observation. Interrupt lower-priority speech, remove stale queued output, and deduplicate repeated faults for 10 s unless state changes. On page hide, pause capture/background requests and route speech; notify on return. On offline or stale backend state, stop remote turns; already-local sensor behavior remains independent.

No voice-input dependency. Text/button controls ship first. No PWA install requirement, service-worker caching of camera frames, browser vibration assumption, spatial-audio claim or background-navigation claim.

## 8. Persistence and data boundary

SQLite is the baseline: `sessions`, `routes`, `checkpoints`, `route_events`, `sightings`, `device_events`, `commands`. Store UTC timestamps, source (`real`/`simulated`/`fixture`), origin (browser/W11/DevKit/simulator adapter), frame identity, checkpoint association and command status. Separate simulated sightings from real recall; require explicit include-simulated in developer screens.

Use SQLAlchemy sessions/transactions and deterministic startup table initialization. Return-route instruction data is explicit. On application restart, expire pending commands and rotate command-session generation so no previous turn can replay. Keep routes/sightings if durable storage exists; export JSON through the UI as a backup.

Deploy with **one worker/instance** while current frames and in-flight jobs are process-local. Render filesystem is ephemeral unless a persistent disk is configured. If an existing persistent disk is available, put SQLite at its mounted path. Otherwise mark memory “this deployment only,” export before video, and do not claim persistence across restart/redeploy. Optional existing Postgres is acceptable only if integration takes <20 minutes; it is not a reason to miss the demo.

## 9. Error and security minimum

All UI APIs require an authenticated demo session. Use a simple team access code configured on the server, verified at `/auth`, returning a secure, HttpOnly, SameSite session cookie for the same HTTPS origin. Local development cookie settings must permit localhost explicitly. One active demo session is sufficient; session UUID is not authentication.

Device uploads/poll/ACK use separate configured camera/feedback bearer tokens. Enforce session/device binding. Firmware secrets, `.env`, DB files and frames are ignored by Git. Do not log authorization headers, API keys or raw images. UI displays source/health, not secrets. `/health` reveals readiness booleans only.

All UI state-changing actions carry a UUID action ID, validated once per session; frame/telemetry/ACK ingestion uses the device sequence/command identity defined in the contract. Request retries reuse the ID. Return the same resulting state or the same resource, not duplicate commands/steps. Source labels are derived from the authorized adapter, not trusted arbitrary client claims. Simulation routes are disabled unless `ALLOW_SIMULATION=true`; simulated events never produce real motor commands.

Errors: `{ "error": { "code": "PERCEPTION_EXPIRED", "message": "Capture a new image.", "retryable": true }, "request_id": "uuid" }`. Use 401/403 auth, 409 busy/state conflict, 413 size, 422 invalid schema, 429 quota/rate, 503 provider/device unavailable and 504 provider timeout. A model failure cannot advance a route or queue a turn.

## 10. Three-person ownership

| Owner | Main mission | Exclusive files | Shared handoff |
| --- | --- | --- | --- |
| **Person 1 / Agent 1** | Backend, perception, memory and application integration | `app/main.py`, `app/settings.py`, `app/schemas.py`, `app/db.py`, `app/dependencies.py`, `app/api/`, `app/services/`, `requirements.txt`, `.env.example` | Publishes schema/health/OpenAPI; mounts Person 2's router; creates UI API stubs before full services. At hardware time owns W11 config/bring-up with Person 2's prepared sketch. |
| **Person 2 / Agent 2** | Device layer, firmware, simulations, deployment and QA | `app/devices/`, `firmware/`, `scripts/simulate_feedback.py`, `scripts/check_deploy.py`, `render.yaml`, `tests/test_devices*`, `qa/`, hardware docs | Supplies `app.devices.router.router`, simulator, ACK/expiry tests, hosted URL. Person 2 owns actual sensor/driver assembly at the end. |
| **Person 3 / Agent 3** | Phone UI, camera adapters, route interaction, audio and accessibility | `web/`, `scripts/seed_demo.py`, `tests/browser/`, teammate README and video script | Uses documented endpoints or fixtures while Agent 1 builds; tests iPhone/AirPods; no wiring, soldering or board flashing. |

Agent 1 alone changes shared schemas, dependency manifest and app assembly; others propose a small patch/message when needed. Agent 2 supplies router modules without independently replacing `main.py`. Agent 3 may call native browser APIs without changing backend contracts. All three can add tests for their code without modifying another owner's tests unnecessarily.

Branches: use the team's existing branches or distinct `backend`, `devices`, `web` work branches. Integrate small working changes at least every 45 minutes, with Person 1 coordinating. Do not wait until hour 5 to merge three untested branches. Do not overwrite another person's files, reset working trees, force-push or rewrite commits. Use configured Git author identity; no Codex co-author trailer.

## 11. Six-hour execution clock

The clock starts from the user's six-hour instruction, not after this document is read. At kickoff, write the real freeze/submission times in `qa/RESULTS.md` and subtract time already spent planning. Never restart the clock to fit unfinished work.

| Elapsed | Agent 1 | Agent 2 | Agent 3 | Gate |
| --- | --- | --- | --- | --- |
| 0–20 min | Recheck repo HEAD; publish schemas, health and route/perception stubs | Inventory parts/docs; create simulator and deployment template | Build phone shell; wire fixtures; test speech gesture | Contracts frozen; roles assigned; key/hosting/device owners known. |
| 20–60 min | Session auth, frame ingest, live YOLO worker, frame age/rate metrics, DB seed | Deploy skeleton HTTPS service; device router skeleton; verify TLS approach | Real Mac/phone capture; actual iPhone/AirPods speech; route buttons | Hosted phone page works by minute 60; live detector demonstration or explicit compute/transport blocker. |
| 60–120 min | Route state, memory, validated perception/age/errors | Telemetry bands, command queue/ACK/expiry, end-to-end simulator | Route flow, overlays, find/recall, priority speech | One integrated route + image + simulated obstacle flow. |
| 120–180 min | Persisted sessions/routes/sightings; error tests | Firmware sketches and compile checks where target known; QA scenarios | Source switching, accessible status, session reload; polish only after API connection | Full P0 software demonstration through hosted URL. |
| 180–240 min | Fix integration; no new framework | Load/fault tests; hardware config package; measure cloud/telemetry latency | iPhone permission/offline/audio tests; optional route import only if gates green | Freeze feature additions at hour 4. |
| 240–270 min | Release candidate and backend fixes | Rehearse simulator and prepare instruments/harness | Final UI flows; export memory; update actual README | All-software acceptance green; firmware/config ready before any assembly. |
| 270–330 min | Human Person 1 integrates W11, with camera-source fallback | Human Person 2 assembles sensor/3 V driver, verifies rails and local alerts | Person 3 handles deployed UI/device binding and logs | Hardware is added only after individual electrical checks; no last-minute blind wiring. |
| 330–360 min | Defects only; tag/record working commit | 15-minute run/fault checks if hardware available; evidence | Rehearse, capture screenshots, final feature/status wording | Build freeze at hour 6. |
| 360–420 min | Record/edit/upload and submit together | Demonstrate physical hardware or disclose fallback | Show phone/UI; operate recording and submission checklist | Submission completed with time to verify links. |

**Inputs humans must supply in the first 20 minutes:** repository access, Gemini key/model, hosting login or an already-working HTTPS service, phone/AirPods access, actual parts inventory and W11 docs if available. Agents can use fixtures while waiting; they must never invent credentials, pin maps or measured results.

### Deadline fallbacks

- No live detector path by minute 45: prioritize the camera-to-detector loop; no optional features. By minute 90 measure the hosted phone loop. A snapshot or fixture cannot be filmed as live perception; disclose any missed gate. Gemini access is secondary.
- No hosted phone URL by minute 60: Person 2 makes deployment the sole priority. A temporary HTTPS tunnel to a stationary Mac is a development/video fallback, explicitly labeled; it does **not** meet the laptop-free runtime acceptance test.
- No integrated P0 software flow by minute 180: stop every P1 and cosmetic animation; all agents fix the end-to-end path.
- No verified W11 pinout when final integration begins: do not guess. Use the real iPhone rear camera, labeled “phone camera fallback.” Board bring-up is reported as pending.
- Sensor or 3 V driver missing at hour 4.5: retain a visibly labeled simulator; film real phone perception/routes and disclose that physical alerts are not validated. Do not delay submission or claim the hardware passed.
- Failed hardware rail/thermal/reset check: power down that channel, isolate it and retain the working software path. No testing on a blindfolded walking participant.

## 12. API and integration expectations

`contracts/API.md` is normative. Keep the existing repository's unversioned endpoint names (`/frame`, `/telemetry`, `/perception`, `/route`, `/memory`, `/status`, `/devices/...`) to avoid another migration. Add session/route/health helpers specified there. Do not independently create `/search`, `/api/analyze` or a different waveform schema in the new app. Do not carry the obsolete snapshot-only prototype into the new app.

At minute 20, the three agents must be able to exchange `contracts/examples.json` without interpretation. GET `/status` is the single UI synchronization surface: route state, current feedback priority, source/freshness, latest observation and device command state. Poll every 500 ms while session is active, back off when paused/offline, and abort on page hide. No WebSocket dependency in this sprint.

Browser POSTs preserve action IDs until a definitive response. Session state remains server-authoritative; browser sessionStorage only remembers session ID and settings, not a competing route controller. The server emits monotonic event sequence numbers; clients ignore older responses so slow polling cannot roll state backward. Don't regenerate speech/haptic output merely because a poll repeats the same event.

## 13. Environment and run contract

Agent 1 must implement and verify these commands in the target repository before claiming completion:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Fill server-side values in .env locally; never commit .env.
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Local browser camera URL: `http://localhost:8000`. Verify `.env` loading through settings rather than assuming the shell loads it. Backend tests: `pytest -q`. Agent 2's simulator: `python scripts/simulate_feedback.py --base-url http://localhost:8000 --session-id SESSION --scenario demo`; token is read from environment or a private prompt, never a command-line secret printed in history.

Required `.env.example` entries:

```dotenv
APP_ENV=development
APP_ACCESS_CODE=
SESSION_SECRET=
GEMINI_API_KEY=
GEMINI_MODEL=
CAMERA_DEVICE_TOKEN=
FEEDBACK_DEVICE_TOKEN=
DATABASE_URL=sqlite:///./data/outlook.db
ALLOW_SIMULATION=true
PERCEPTION_PROVIDER=gemini
LIVE_DETECTOR_MODEL_PATH=./models/detector.onnx
LIVE_VISION_TARGET_HZ=5
LIVE_VISION_MAX_AGE_MS=1000
PUBLIC_BASE_URL=http://localhost:8000
MAPBOX_ACCESS_TOKEN=
```

Generate strong local/session/device secrets; no committed defaults. `PERCEPTION_PROVIDER=fixture` is allowed only with simulation enabled and must be obvious in UI/responses. A missing real key with `provider=gemini` returns unavailable; it never silently selects fixtures. Production should disable simulation except a separately authenticated developer session used for an honestly labeled fallback.

Render deployment baseline: root build command `pip install -r requirements.txt`; start command `uvicorn app.main:app --host 0.0.0.0 --port $PORT --workers 1`; health path `/health`; store secrets in hosting settings, never `render.yaml`. Serve web assets from the app. Set public URL/cookie environment correctly. If using a disk, set DB path to its actual mount. Choose an available hosting plan with known availability/idle behavior; do not purchase a plan without team authorization. Test a cold start early and recheck before recording.

Deploying code is necessary; declaring success after generating a YAML file is not. Agents may prepare an exact deploy command/config if human account access is unavailable, but must mark the external action blocked rather than claim a live URL.

## 14. Firmware and final physical integration

Person 2 creates both sketches and ignored `secrets.h` templates. Use the team's tested Arduino-ESP32 core version and record it. Config defines backend HTTPS URL, session ID, device ID, device token, Wi-Fi credentials and root CA; no key printing. Validate TLS with a CA and synchronized time; don't fix connection failures with permanent `setInsecure()`.

**Camera sketch:** matching W11 vendor pin map only; capture, sequence/frame metadata, time sync, POST raw JPEG, release buffers on every path, bounded reconnect and no accumulated frame queue. Unknown board configuration intentionally fails with a useful configuration error. A compile-only test under an invented pin map is not bring-up evidence.

**Feedback sketch:** GPIO18 TRIG, GPIO19 divided ECHO, GPIO23 buzzer transistor, GPIO25 single motor MOSFET; GPIO26 optional second motor. Separate sensor/actuator timing from network I/O. Poll commands around every 500 ms when healthy; acknowledge acceptance/completion/rejection. Distinguish boot IDs, command generations and command expiry. No remote command is allowed to disable local obstacle warnings.

**Known power rules:** HC-SR04 and specified piezo buzzer on verified 5 V rail; ECHO through 1 kΩ top/2 kΩ bottom divider; motor through a logic-level MOSFET, diode and **regulated 3.0 V buck supply**, not GPIO/5 V/unchecked 3V3 rail. Common sensor/driver ground, flyback stripe to motor positive, motor starts OFF. See `HARDWARE_WIRING.md` for full connections, regulator/decoupling and optional TRIG buffer. Verify board clone rail behavior and actual transistor lead order.

At hour 4.5: inspect unpowered wiring → measure rails/divider → sensor only → buzzer → motor → camera power/network → bind session → single direction ACK/output → obstacle priority → combined power/heat checks → mounting. Person 3 never performs electrical work. Never attach all loads first and debug afterward.

Required hardware handoff from agents: firmware source, exact board/core settings, build command/tool used, expected serial messages, configuration template, labeled pin map, network credentials entry method, test procedure and known blockers. Physical assembly belongs to humans; agents do not mark it complete based on code generation.

## 15. Acceptance matrix

Every row records **PASS / FAIL / BLOCKED / NOT RUN**, actual source, timestamp, device and evidence in `qa/RESULTS.md`. “Mock passes” and “hardware passes” are different outcomes.

| ID | Test and expected result | Owner |
| --- | --- | --- |
| A01 | Clean dependency install/start; missing secrets cause a useful error/unavailable state, no secret output | 1 |
| A02 | Hosted `/health` and phone HTTPS UI reachable with Mac app/server stopped; this is the no-carried-laptop proof | 2/3 |
| A03 | Browser camera denied → actionable state; real iPhone frame captured after permission | 3 |
| A04 | Continuous detector with current-frame boxes and measured age/rate; run L01–L06 in LIVE_VISION.md. Gemini identify/search is optional enrichment; no fixture presented as live AI. | 1/3 |
| A05 | Corrupt/oversized frame, invalid JSON/box/NaN, stale timestamp, replaced source/result all rejected | 1 |
| A06 | Route start/confirm/repeat/pause/resume/stop/completion; repeated action ID advances once | 1/3 |
| A07 | Reload preserves route/progress and correct sightings; simulated sightings excluded from real recall; persistence limitation visible | 1/3 |
| A08 | AirPods speech audibly works on actual iPhone; stop/fault interrupts observation and no duplicate polling announcements | 3 |
| A09 | Simulator sends nonwarning/warning/urgent/invalid/stale/reboot events; state never labels no-echo as clear | 2 |
| A10 | Commands expire, deduplicate, bind device/session, ACK once; network/boot/source change cannot replay a turn | 2 |
| A11 | Physical one-motor patterns and local buzzer correct; 3 V supply stable; obstacle preempts remote turn | 2, hardware |
| A12 | Internet disabled while sensor powered: local alert still functions; phone cloud states unavailable | 2/3, hardware |
| A13 | Three checked route demonstrations, five object searches, ten flat-target approaches; record misses | all, applicable sources |
| A14 | 15-minute combined-power run, heat/rail/reset check and measured local warning latency | 1/2, hardware |
| A15 | VoiceOver labels, focus, touch controls, camera source/status/freshness and Stop accessible | 3 |
| A16 | No API key/credential in Git, screenshots, browser bundle or logs; invalid UI/device token rejected | 1/2 |

Bench policy tests use a fake clock, e.g. telemetry received at 0 ms valid at 900 ms and stale at 1001 ms; command expiry at 1500 ms cannot execute at 1501 ms. Perception tests stub model responses; at least one live model test requires real account access. UI smoke tests use synthetic camera input where available and a separate manual physical-device check.

Targets are provisional: local obstacle reaction <500 ms, fresh observation age ≤5 s, command acceptance ACK within 1 s on a healthy connection. Record capture-to-output, network and inference timing separately. Do not substitute published model benchmarks for actual measurements.

## 16. Agent completion standard

Each agent receives `AGENTS.md`, this spec, `contracts/` and its workstream brief. It must implement its owned files end to end, run relevant checks, fix failures and supply exact launch/test commands. It may make routine decisions inside this contract without repeatedly asking for approval. It must not expand scope, invent credentials/pinouts, publish unsupported capabilities or stop at a plan/pseudocode.

Every 45-minute handoff: working branch/commit, completed feature IDs, changed interfaces, passing tests, exact blockers and the next integrated test. A provider/account/physical-hardware blocker is explicit; continue independent work with labeled adapters. Never silently downgrade the user's navigation objective into an object-finder demo.

## 17. Video and submission hour

Build freezes at hour 6. Use the next hour approximately as 20 minutes recording, 20 minutes editing, 15 minutes upload/forms, 5 minutes final link/permission verification. If organizer requirements differ, the team must adapt before recording; no competition-specific duration/rules are assumed here.

Suggested 2–3 minute story: problem and device overview (15 s); phone starts a checked route and AirPods speech (35 s); controlled obstacle triggers real local alert/vibration or an explicitly labeled simulation (30 s); repeat/pause/route memory (20 s); real object search/last-seen age (25 s); cloud/no-laptop architecture and limitations/next steps (15 s). A sighted teammate/spotter demonstrates; no blindfolded walking or road crossing.

Submission checklist: project name consistent; repository accessible; actual install/start commands; deployed URL tested in a fresh phone browser; video permission tested signed out; hardware diagram/photos; feature status table; provider/tools attribution and any required Kiro evidence; measured results; known limitations; all organizer fields; final link saved by a teammate. Do not include raw API keys, private user images or claims that simulations were physical tests.

## 18. Source basis

- [Reviewed repository snapshot](https://github.com/adhyannsingal/stride/tree/8d19944af6acc6e10352fb01cec846f7c84dd196)
- [Original build spec](https://github.com/adhyannsingal/stride/blob/8d19944af6acc6e10352fb01cec846f7c84dd196/buildspec_outlook.md) and [README](https://github.com/adhyannsingal/stride/blob/8d19944af6acc6e10352fb01cec846f7c84dd196/README.md)
- [Gemini image understanding](https://ai.google.dev/gemini-api/docs/image-understanding) and [structured output](https://ai.google.dev/gemini-api/docs/structured-output)
- [FastAPI on Render](https://render.com/docs/deploy-fastapi), [persistent disks](https://render.com/docs/disks) and [free-service storage limitations](https://render.com/docs/free)
- [Browser camera requirements](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia) and [speech API](https://developer.mozilla.org/en-US/docs/Web/API/Web_Speech_API)
- [Optional Mapbox walking directions](https://docs.mapbox.com/api/navigation/directions/)
- [Espressif camera driver](https://github.com/espressif/esp32-camera) and [TLS example](https://github.com/espressif/arduino-esp32/blob/master/libraries/NetworkClientSecure/examples/WiFiClientSecure/WiFiClientSecure.ino)
- [iPhone 14](https://support.apple.com/en-us/111850), [AirPods Pro 3](https://www.apple.com/airpods-pro/specs/), [ARKit depth requirements](https://developer.apple.com/documentation/arkit/arframe/scenedepth)

The existing repository mentions Kiro and Hackachusetts. Preserve the team's Kiro workflow where applicable, but verify organizer requirements directly; this spec does not independently assert event eligibility, deadlines or tool mandates.
