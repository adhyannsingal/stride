# Start the Outlook team

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

1. Recheck `adhyannsingal/stride` HEAD. The reviewed snapshot `8d19944` contained two planning documents; preserve anything teammates have added since.
2. Copy this handoff's README, `buildspec_outlook.md`, `AGENTS.md`, `contracts/`, `agents/`, hardware guide, QA/submission templates into the repository. The package contains the current implementation contract, not the new finished app.
3. Set the actual build-freeze and submission times in `qa/RESULTS.md`. Six-hour build budget includes time already spent planning. Reserve the following hour for recording/submission.
4. Give each coding agent the repository checkout and its corresponding brief; it must also read the shared spec and contract. Assign one human owner per workstream.

| Human | Give its agent | First integrated result |
| --- | --- | --- |
| Person 1 | `agents/01_BACKEND.md` | Schemas/session/health, then automatic fresh frames → YOLO results |
| Person 2 | `agents/02_DEVICES.md` | HTTPS deployment and simulated sensor → alert → acknowledged command path |
| Person 3 — software only | `agents/03_PHONE_APP.md` | iPhone camera, AirPods speech and route flow connected to the shared API |

5. Supply detector model/runtime, hosting access and optional Gemini key/model, device availability and vendor board documentation privately. These are human/account inputs; agents must not invent them.
6. Integrate every 45 minutes. Phone HTTPS/audio by minute 60; end-to-end software flow by hour 3; feature cutoff hour 4; physical wiring hours 4.5–5.5; build freeze hour 6.
7. Use `qa/RESULTS.md` to record what actually passed and `submission/CHECKLIST.md` for the final hour.

## Copy-paste kickoff

> Implement your assigned Outlook workstream now. Read AGENTS.md, buildspec_outlook.md, contracts/API.md and your agent brief. Recheck current code and preserve teammates' work. Build and test owned files end to end; don't stop at a plan. Use explicit mocks while external hardware/credentials are unavailable, keep sources visible, and integrate against the shared contract. Report actual passing checks, exact blockers and runnable commands. The deadline clock is already running; no new frameworks or unapproved scope expansion.
