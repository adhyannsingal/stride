# Stride

AI-powered navigation assistance glasses for blind and low-vision users: checked-route guidance, immediate obstacle alerts, continuous objects-ahead awareness, AirPods speech and directional vibration. Object finding and last-seen recall support the navigation experience.

**Status:** implementation handoff. At the reviewed branch snapshots the repository contained planning documents, not an executable application. Run commands, deployment and physical operation must be delivered and verified by the agents; no completed feature is implied here.

## Team assignments

| Owner | Responsibility | Give the agent this file |
| --- | --- | --- |
| Agent 1 | Backend, contracts, route/memory, server device policies, deployment | [Backend brief](Agent_1_Backend.md) |
| Agent 2 | Frontend, automatic browser capture, accessible controls and speech | [Frontend brief](Agent_2_Frontend.md) |
| Agent 3 — Adhyann | Vision model/service, W11/DevKit firmware, hardware and integration | [Hardware/vision brief](Agent_3_Hardware_Vision.md) |

Each brief defines exclusive paths, interfaces, implementation order, tests and handoff. Agent 1 owns shared files. Agent 3's **Integration plan for all three agents** explains branch/merge order and time gates. These assignments supersede older briefs.

## What we are building

- Guided routes with explicit checkpoint confirmation, repeat/pause/stop and Route Memory.
- Continuous live recognition after one Start, using fresh frames and stabilized announcements.
- Independent HC-SR04 proximity warnings via a separate ESP32, buzzer and protected 3 V motor.
- Spoken route/object/fault events through the iPhone and AirPods; distinguish real versus simulated output.
- Find supported objects and recall last-seen timestamp/checkpoint/source. Optional Gemini adds requested descriptions after the core passes.

```text
W11 glasses camera → HTTPS JPEG → hosted FastAPI + YOLO → iPhone web app → AirPods
HC-SR04 → DevKit → local buzzer / protected 3 V motor (works without cloud)
Checked route → backend → expiring direction command → DevKit
```

MacBook/webcam is for development; no carried laptop in the final runtime. Browser/phone camera and sensor simulation unblock development tonight and remain visibly labeled fallbacks. OpenCV supports image handling; YOLO does detection. Gemini is outside the continuous loop.

## Build and integration

Start with [the team build spec](buildspec_stride.md), [shared API](contracts/API.md), [live requirements](Stride_Live_Vision_Requirements.md) and [full hardware wiring guide](Stride_Hardware_Wiring_Guide.md). This handoff contains the same agent briefs/contracts plus QA and submission templates. Agents should use repository files directly; extracting the ZIP over a working checkout is unnecessary.

The shared contract fixes one frame endpoint, a mounted vision service, a backend-owned feedback arbiter and frontend-owned speech playback. Merge small working slices every 45 minutes. Prove phone → hosted detector → phone first, then sensor simulation/commands, then W11 and physical hardware. Reserve final build time for hardware checks and a separate hour for video/submission. Use actual remaining time.

Target 5 fresh detections/s and capture-to-result p95 ≤500 ms over 60 s; measure, do not assume. Frames older than 1000 ms are not current-scene speech. Late frames/events, duplicate actions and expired commands must not replay. Missing detection never means clear path. A fixed-label detector cannot guarantee every hazard, metric depth or a safe turn.

Exact W11 pinout is still a vendor/PCB verification gate. HC-SR04 ECHO needs a divider; the 3 V motor needs a regulated supply/driver/diode. Standard iPhone 14 has no LiDAR. Normal AirPods speech is included; world-anchored audio is not a required or proven feature.

## Before claiming completion

Each agent supplies actual launch/test commands, commit, passing checks and blockers in its own `handoff/` and `qa/` file. Backend owner updates this README with verified runnable setup once code exists. Keep secrets/images/databases out of Git and use configured Git attribution.

Demonstrate on a checked controlled route with a sighted spotter. Stride targets navigation assistance; this prototype is not validated for independent blind walking or road crossings.
