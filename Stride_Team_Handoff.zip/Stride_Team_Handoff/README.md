# Stride

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

### Navigation assistance glasses for blind and low vision users

Stride combines spoken route guidance, local obstacle alerts and directional vibration. Camera-based object awareness helps users understand what is ahead, find an object and recall where it was last seen. Navigation is the primary purpose; object finding is a supporting feature.

**Repository:** [adhyannsingal/stride](https://github.com/adhyannsingal/stride). The project and repository are named **Stride**.

## Current status

The reviewed `main` snapshot, `8d19944`, contains a README and a build spec, not a completed application. This README describes the six-hour implementation target. Update feature status only after testing; use [qa/RESULTS.md](qa/RESULTS.md) for actual evidence.

The team has **six hours for implementation and hardware integration, followed by one hour for video and submission**. Start with working software and simulated device adapters; add physical hardware in the final build window. Person 3 works exclusively on software.

## What we are building

| Feature | Implementation for this sprint |
| --- | --- |
| Guided navigation | Select a checked route, hear the next instruction, confirm checkpoints, repeat, pause/resume and stop. Progress is explicitly confirmed. |
| Obstacle alerts | HC-SR04 and ESP32 produce local buzzer/motor alerts without waiting for internet or AI. |
| Directional vibration | A single 3 V wrist motor encodes left/right/straight/stop using distinct pulse patterns. A second motor is optional. |
| AirPods instructions | The iPhone web app speaks route instructions and observations through its selected output, including paired AirPods Pro 3. |
| Live objects ahead | Glasses frames are processed automatically by a hosted YOLO detector; current boxes and stabilized spoken updates report what the model detects. No repeated Analyze clicks. |
| Find an object | Search for a named object; report its image position or not found. |
| Route Memory | Store checked route steps, confirmed progress and separately checked return directions. |
| Last-seen memory | Recall an object's label, last confirmed checkpoint association and sighting age. |
| Accessible controls and health | Large labeled controls, VoiceOver support, camera/device source, freshness, AI availability and command acknowledgment. |

All features above are implementation targets, not claims of completed hardware validation. Simulated readings and fixtures must stay visibly labeled.

## How it works without carrying a laptop

```text
Glasses camera → continuous Wi-Fi/HTTPS → Hosted FastAPI + YOLO
                                                    └→ optional Gemini query
                                     │
                            routes, memory, feedback
                                     │
                                     ▼
                         iPhone web app → AirPods speech
                                     │
                              direction command
                                     ▼
HC-SR04 → ESP32 DevKit → local buzzer + protected 3 V motor
```

The MacBook is a development station. The final wearable demonstration uses a **hosted backend**, the iPhone and internet-connected glasses/controller. Verify the phone app still works with the Mac development server stopped.

While hardware is unavailable, the app uses the phone/Mac camera and a labeled feedback simulator. Camera source changes do not require rewriting perception. When the W11 is ready, swap the frame adapter; when the sensor/motor is ready, swap the feedback adapter.

## Technology choices

- **App:** HTTPS mobile web interface, vanilla JavaScript and browser speech; foreground operation on iPhone 14 Safari.
- **Backend:** Python 3.11, FastAPI, Pydantic, one Uvicorn worker.
- **Recognition:** continuous hosted YOLO detection is core; selected snapshots can go to Gemini for richer descriptions. Measure actual camera-to-result age/rate; no universal hazard-detection claim.
- **Memory:** SQLite, with export and explicit storage-durability status. Hosting restart persistence requires configured durable storage.
- **Firmware:** W11 JPEG uploader and independent DevKit sensor/feedback controller.
- **Deployment:** same-origin UI/API on a tested HTTPS host; Render is the documented baseline.

YOLO runs on a deployed server for this sprint, not a laptop carried by the wearer. OpenCV may support frame processing/tracking. Gemini is optional; local DevKit obstacle reactions must not wait for cloud vision. See LIVE_VISION.md for strict live-loop gates and the later on-phone Core ML option.

## Navigation and perception are separate

A saved route provides the direction to take. A camera box provides image-relative location. The ultrasonic sensor provides coarse forward proximity. None of these automatically proves a safe alternative path or that a particular detected object is at the measured ultrasonic distance.

Examples: “Chair, left side of camera view”; “Nearby obstacle”; “At confirmed checkpoint B, turn right.” Do not combine unrelated measurements into “chair 40 cm away,” and do not turn right solely because a chair appeared on the left.

The baseline does not automatically locate the wearer or reroute. Optional walking-route import can use a map provider after the baseline passes, while retaining explicit checkpoint confirmation.

## Team allocation

| Person | Owns | Agent brief |
| --- | --- | --- |
| 1 | Backend, live YOLO, optional Gemini, memory, shared contracts and application integration; W11 bring-up during final assembly | [Backend brief](agents/01_BACKEND.md) |
| 2 | Device APIs/simulators, firmware, deployment, tests and final sensor/motor assembly | [Devices and integration brief](agents/02_DEVICES.md) |
| 3 — software only | Phone/web UI, camera adapters, route interaction, speech, accessibility and demo flow | [Phone app brief](agents/03_PHONE_APP.md) |

Read [the build spec](buildspec_stride.md), [shared agent instructions](AGENTS.md) and [API contract](contracts/API.md) before coding. Work on separate files/branches, integrate every 45 minutes, and deliver runnable code with tests rather than plans or placeholders. Keep the team's existing Kiro workflow if applicable; confirm organizer requirements separately.

## Run the new app after the agents implement it

These are required implementation commands, **not verified against application code in the reviewed docs-only snapshot**:

```sh
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Configure .env locally, then:
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Open `http://localhost:8000`. Run `pytest -q`. Required configuration includes the app access code/session secret, live-detector model/runtime, separate camera/feedback device tokens and database URL. Gemini key/model are needed only for optional Gemini features. See the build spec for the complete environment contract. Never commit secrets or raw camera images.

For phone testing, use the deployed HTTPS origin; a plain HTTP LAN address is not a substitute for browser camera permissions. Exact deploy URL and tested dependency versions must be added here by the team.

## Hardware

Confirmed design: W11 ESP32-S3/OV3660, ESP32 DevKit V1, HC-SR04, active piezo buzzer, 3 V vibration motor, switching drivers and pocket USB bank. iPhone 14 and AirPods Pro 3 provide the app/audio interface.

Read [HARDWARE_WIRING.md](HARDWARE_WIRING.md). The motor needs a regulated 3 V supply and MOSFET/flyback protection; HC-SR04 ECHO needs a divider before the ESP32 input. W11 camera GPIOs must match its exact verified PCB revision. Firmware generation is not evidence that wiring or board configuration was tested.

The standard iPhone 14 has no LiDAR. World-anchored sound, native head tracking, automatic navigation and universal hazard detection are not part of this sprint.

## Deadline and demo

First prove the live detector path in 45 minutes, then the hosted phone loop by minute 90; see LIVE_VISION.md. By hour 1, also smoke-test phone audio/permissions. By hour 3: integrated route, recognition and simulated alert flow. At hour 4: stop adding features. Hours 4.5–5.5: physical integration if parts/configuration are available. At hour 6: freeze and record the working commit.

Use the next hour to record, edit, upload and verify submission links. Demonstrate route guidance, real local alerts if validated, Route Memory and continuous automatic object detection. Explicitly label any camera fallback or simulated hardware. Test installed hardware on a controlled route with a sighted spotter; the prototype does not establish safe independent navigation.

## Sources

[Gemini image understanding](https://ai.google.dev/gemini-api/docs/image-understanding) · [FastAPI deployment](https://render.com/docs/deploy-fastapi) · [Browser camera requirements](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia) · [Espressif camera driver](https://github.com/espressif/esp32-camera) · [iPhone 14](https://support.apple.com/en-us/111850) · [AirPods Pro 3](https://www.apple.com/airpods-pro/specs/)
