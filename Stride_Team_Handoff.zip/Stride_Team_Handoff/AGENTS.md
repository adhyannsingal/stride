# Stride agent implementation instructions

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

## Objective and authority

Deliver the build in `buildspec_stride.md` against `contracts/API.md`. Read your brief under `agents/` and implement its owned workstream. The team has six hours to build including final hardware integration, then one hour to record/submit. Check the team's actual remaining time; do not restart its clock. Preserve any newer code found after the reviewed docs-only snapshot.

Product name is Stride; existing repository name remains `stride`. Prior 36–48-hour/laptop-runtime/5 V motor instructions are superseded. Standard iPhone 14 has no LiDAR; motor is rated 3 V. Navigation is central; do not reduce the application to object finding.

## Work behavior

- Implement working vertical slices, not plans, pseudocode, fake success responses or disconnected modules.
- Work immediately with provided fixtures and explicit simulated sources; connect real adapters when available.
- Freeze shared API models within the first 20 minutes. Agent 1 owns shared schemas/dependencies/app assembly, Agent 2 devices/firmware/deploy, Agent 3 web UI/audio.
- Do not edit another owner's files without a small coordinated interface change. Do not overwrite concurrent work.
- Keep one model request in flight per session, current frames only and source/freshness checks at speech time.
- Local sensor/stop feedback takes priority; Gemini never generates a guaranteed safe walking path. Simulated readings cannot unlock real-hardware mode or be reported as physical evidence.
- Do not add new infrastructure, frameworks, agent frameworks, native iOS app, custom YOLO training, vector DB or TimescaleDB during this sprint.
- Make routine implementation decisions yourself within this contract. Ask only for missing credentials, board facts, account access or genuinely material product choices. Continue independent tasks while blocked.
- Do not invent W11 GPIOs, secret values, live URLs, successful deployment, measured latency or hardware test outcomes.
- Do not buy hosting or publish messages to others without explicit human authorization. Prepare exact deployment steps when access is unavailable.

## Verification and handoff

Run checks that exercise behavior: state/idempotency, stale data, error handling, auth, command expiry and source isolation. Use fake clocks/provider fixtures for deterministic tests, plus a separately recorded live-device/provider check. Update `qa/RESULTS.md` with PASS/FAIL/BLOCKED/NOT RUN, actual source and evidence. Update README run instructions only after verifying them.

Every 45 minutes provide branch/commit, completed IDs, changed interfaces, passing checks, blockers and the next end-to-end test. Integrate early. Finish with exact start/test commands, changed files, remaining limitations and known external/hardware blockers.

## Git and secrets

Use configured Git author identity. Do not add any Codex co-author trailer or other Codex attribution. Preserve existing human contributor attribution and never rewrite commits for attribution. No force-push/reset of other work. Never commit .env, API/device keys, firmware secrets, private images, personal observation databases or recordings containing secrets.
