# Agent 2 — Devices, firmware, deployment and QA

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](../LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

You own the device/integration workstream for Stride in `adhyannsingal/stride`. Read the shared instructions, build spec, API contract and hardware wiring guide. Build software/firmware against mocks now; physical assembly happens near the end. Implement, test and hand off; do not stop at architecture.

## Own these files

`app/devices/`, `firmware/`, simulator/check-deploy scripts, `render.yaml`, device-policy tests, `qa/` and hardware handoff notes. Supply `app.devices.router.router` for Agent 1 to mount. Do not replace `app/main.py`, shared schemas or Agent 3's web code.

## Execution order

1. First 20 minutes: reconcile shared models with Agent 1; inventory actual parts and W11 vendor evidence with the human. Create scenario fixtures and device-state/command interfaces independent of hardware.
2. First hour: get the skeleton app onto a public HTTPS host with a phone-reachable health check. Prepare config if account access is missing; mark it blocked and continue. No unauthorized purchase. One worker, correct secrets, no raw credentials in YAML/logs.
3. Build telemetry freshness/bands/boot-sequence handling, device binding, priority overlay and command queue. Queue at most one remote direction; implement deduplication, remaining TTL, session/boot generation, ACK states and cancellation. Simulation never marks physical output complete.
4. Build `simulate_feedback.py` with nonwarning, warning, urgent, invalid/no-echo, stale/link-loss, reboot and ACK-delay scenarios. Use environment/private-prompt token entry. Make it exercise the actual API.
5. Prepare W11 camera uploader firmware with verified-board configuration gate and secure HTTPS. Unknown pinout must fail clearly; don't substitute AI Thinker values. Prepare DevKit local sampling/alert state machine, network task and expiring command handling.
6. By hour 3: verify integrated phone route + perception + simulated obstacle priority. Record tests; make deployment reliable before cosmetic work.
7. Hours 4.5–5.5: human Person 2 measures rails/divider/regulator, assembles HC-SR04, buzzer and protected 3 V motor in stages. Person 1 handles W11. Support logs/ACKs and diagnose; code generation is not physical validation.
8. Final 30 minutes: run/rehearse working configuration, record the deployed URL and source/status limitations, freeze changes except failures.

## Hardware constants

DevKit GPIO18 TRIG; GPIO19 ECHO through 1 kΩ top/2 kΩ bottom divider; GPIO23 transistor-switched active piezo buzzer; GPIO25 MOSFET-switched **3 V** motor; GPIO26 optional second motor. Motor supply is a regulated 3.0 V buck with diode/suppression/common ground. See the full guide. Never connect the motor directly to GPIO or 5 V.

Local sensor loop is independent of TLS/HTTP/model calls. 100 ms sample cycle, 30 ms timeout, median 3, starting warning bands 100/60/30 cm and 5 cm hysteresis. Unknown/no echo is not clear. The stop waveform preempts remote turns; no stale replay after recovery. Motors default off. `cancel` does not disable local obstacle alerts.

## Tests and deliverables

Own A02 deployment, A09–A12, A14 and shared A16. Use fake-clock tests for TTL/freshness, duplicate/out-of-order packets, retired boot IDs, new generation, invalid numbers, simulator/physical isolation, delayed ACK and stop priority. Test hosted health/phone origin with the Mac app server stopped. Record actual physical results separately if parts are available.

Deliver both firmware projects/config templates, exact board/core/compile settings, no-secret simulator CLI, hosted URL or exact deployment blocker, measured QA report and final wiring/bring-up checklist. Do not promise fixed camera GPIOs until the physical PCB is identified.

## Live transport and hosting gate

Prove the detector host fits actual CPU/memory and returns fresh results at measured sustained rate. W11 must upload continuously at a tested rate with capture timestamps; handle drops and reconnect without backlog. Validate the final glasses-to-phone path separately from webcam tests. Local sensing remains independent. See L01–L06.
