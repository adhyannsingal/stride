# Agent 3 — Phone app, camera, route UI and AirPods

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](../LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

You own the application interface for Stride in `adhyannsingal/stride`. Read `AGENTS.md`, build spec and API contract. You work **exclusively on software**; no wiring, soldering or flashing. Implement the owned workstream now, with real browser APIs and fixtures for unavailable backend/device functions.

## Own these files

`web/`, `scripts/seed_demo.py`, `tests/browser/`, teammate README run/status sections and submission video script. Backend endpoints/models belong to Agent 1; device/firmware/deployment to Agent 2. Do not fork a second backend or change contract names independently.

## Execution order

1. First 20 minutes: phone-sized accessible shell and typed/documented API adapter against `contracts/examples.json`; large Stop, Begin route, Confirm, Repeat, Pause/Resume, Describe, Find and Recall controls.
2. First hour: real Mac webcam/iPhone rear-camera capture; unmirrored image orientation, user gesture speech test and actual iPhone/AirPods smoke test. Test over Agent 2's HTTPS origin early. Plain HTTP LAN camera access is not the target.
3. Implement authoritative session/route polling, event-ID deduplication, source/health badges, route selection/editor/import, progress and history. Duplicate polling must not re-speak directions or repeat vibrations. Persist only session ID/settings locally; backend owns progress.
4. Wire raw JPEG upload and describe/find requests, bounding-box overlays, current-frame identity and source revision. Freshness must be checked at speech time, not just request time. Display not-found, expired and unavailable without fake fallback detection.
5. Implement prioritized speech cancellation; obstacle/fault interrupts route/observation. Pause/hide/offline cancels ongoing noncritical speech and capture; resume requires explicit gesture/checks. AirPods output is selected through iOS/macOS, not forced by code.
6. Implement real versus simulated haptic displays and command ACK status. One-motor patterns are distinct pulses, not physical left/right sensation. Visual animation is not motor validation.
7. Hour 2–3: integrate real APIs and run the complete route + perception + simulator story. After hour 4 focus only on defects/accessibility/submission.
8. Hardware integration window: bind real devices/select W11 source, log ACK/output states while Persons 1/2 assemble. Keep phone-camera and simulator fallbacks clearly labeled. Update README with verified commands/status.

## Scope limits

No React/Next migration, native iOS app, browser-vibration dependency, LiDAR, world-anchored audio or speech-recognition dependency. Standard iPhone 14 has no LiDAR. Keep app foreground for demo. The final app must run from public HTTPS with no Mac backend required.

Optional GPS walking-route import is allowed only after P0 is green, an existing provider token is available and there is a maximum 30-minute timebox. Keep explicit confirmation; do not implement unreliable automatic turning or change destination scope into a geocoding project.

## Tests and deliverables

Own A03, A08, A15 and frontend parts of A04/A06/A07. Test permission denial, front/rear orientation, in-flight source replacement, stale observations, repeat/pause/stop, poll deduplication, higher-priority interruption, lost backend, VoiceOver/focus/touch controls and actual AirPods playback.

Deliver working phone UI/API integration, brief manual-device test checklist, browser checks where feasible, sample route clearly marked illustrative, current README and a 2–3-minute video flow. Distinguish actual device results from synthetic-camera checks and future work.

## Automatic live camera loop is mandatory

Start navigation activates capture/detection once, then automatically supplies frames and renders fresh results until pause/stop. Implement live state/age/rate badges, source invalidation, track/event deduplication, stable concise announcements and stale/live-loss handling from LIVE_VISION.md. Repeated Capture/Analyze clicks are only the optional Gemini path.
