# Agent 1 — Backend, perception, memory and integration

> **Current architecture:** continuous automatic perception is P0. Read [LIVE_VISION.md](../LIVE_VISION.md) first; it defines the mandatory live loop and its acceptance gates. Hosted YOLO handles the live loop; Gemini is optional enrichment. Implementation and physical validation remain to be completed by the team.

You are the backend/integration engineer for Stride in `adhyannsingal/stride`. Read `AGENTS.md`, `buildspec_stride.md` and `contracts/API.md`. Recheck existing code before creating files. Implement this workstream now, end to end; do not return only a plan.

## Own these files

`app/main.py`, `app/settings.py`, `app/schemas.py`, `app/db.py`, `app/dependencies.py`, `app/api/`, `app/services/`, `requirements.txt`, `.env.example`, backend route/perception/memory tests. You own shared model signatures/dependencies. Mount Agent 2's `app.devices.router.router`; serve Agent 3's `web/` at the same origin. Do not replace their files. You coordinate merge/integration decisions.

## Execution order

1. First 20 minutes: Python 3.11 FastAPI skeleton, `/health`, shared Pydantic models, session creation/auth, route/perception/status stubs matching contracts. Return explicit unavailable where unfinished; provide example payloads to the other agents.
2. First 45 minutes: prove automatic live YOLO detections; implement raw JPEG validation/latest-frame storage and identity/source age checks. By minute 90 measure the hosted phone loop. Gemini integration is optional after the live gate passes, never a dependency for continuous detection.
3. Implement DB tables, checked-route CRUD/state, idempotent actions, memory/recall with ages and exports. Use transactions and server-authoritative event sequences. Never advance on Repeat or duplicate Confirm.
4. Implement describe/find schema validation, bounded concurrency/timeouts, max call count, positions from boxes, stale/mismatched-result rejection and error surfaces. Text in images is untrusted scene content.
5. Connect the feedback priority state from Agent 2 to route/perception output. A pending model result must not override a newer obstacle event.
6. Hour 2–3: complete end-to-end route + image + simulated alert integration with Agent 3. At hour 4 stop scope expansion and fix failure cases.
7. At hardware time, human Person 1 verifies W11 board docs/pins and camera bring-up using Agent 2's prepared firmware; you support frame ingest/configuration. Do not fabricate a working camera based on a compile check.

## Mandatory rules

- Public hosted backend, not a Mac required during use. One process/worker while state/frame jobs are process-local.
- Server secrets only; same-origin cookie auth, device-token routes, input limits and source isolation.
- No mandatory new database/service account. SQLite with explicit durability and export; configured disk if available.
- Camera origin changes invalidate in-flight observations. Live speech maximum frame age 5 s. Timeout 12 s; no blind retry storm.
- No synthesized confidence, safe-path instruction, metric distance or autonomous turn decision from model boxes.

## Tests and deliverables

Pass A01, A04–A07 and your part of A16. Test duplicate route action IDs, invalid JSON/boxes/NaN, 413 image size, concurrent busy, provider timeout/429, frame-source switch, fake-clock expiry, memory source filtering and persistence limitations. Include at least one real-provider smoke result if credentials are available, otherwise mark blocked.

Deliver runnable backend, pinned requirements, environment example, actual launch/test commands, session/config instructions, integration notes and evidence in `qa/RESULTS.md`. Update `/health` with the actual commit/version. Final handoff states exactly what ran versus what awaits credentials/hardware.

## Live perception replaces the earlier first priority

Implement the hosted lightweight YOLO/ONNX worker, newest-frame slot, live APIs, source/clock/age checks and sustained throughput measurements from LIVE_VISION.md first. Gemini becomes optional enrichment. A manual image-description endpoint is not completion of the vision task.
