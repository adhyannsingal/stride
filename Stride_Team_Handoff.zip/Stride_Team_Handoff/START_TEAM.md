# Start the Stride team

Give Agent 1 `Agent_1_Backend.md`, Agent 2 `Agent_2_Frontend.md`, and Agent 3 (Adhyann) `Agent_3_Hardware_Vision.md`. Read `contracts/API.md` and use the integration plan in Agent 3's brief. These replace all earlier role numbering. Use current repository files directly; never overwrite newer code with an extracted archive. Implement with webcam/simulator now; assemble hardware in the final build window. Use actual remaining time.
